
# Create a Tableau Story - by Wilson Lo

## Project Title: United States Flight Delays and Performance in 2017

### Source of Data Set: United States Department of Transportation


## Summary
The data set contains information on United States flight delays and performance in 2017. The story has first shown an overview trend on the flight issues across every month due to different types of delay, cancelled flights and diverted flights, in terms of number of flights and in minutes. Then a deeper look on the details of flight delays for each airport and carrier are displayed. With the information presented, each airport and carrier could know their own problem, and create solutions specifically for each type of delay, or for the peaks of months that had the most serious delay issues.

## Design Before Feedback
### Link of Tableau Workbook: 
https://public.tableau.com/views/StoryonUSFlightsDelayandPerformance2017-BeforeFeedback/Story1?:embed=y&:display_count=yes&publish=yes

There are 7 slides in total for the story. 

**For the flow of the story, the first 3 slides are designed to first explained an overview trend of different types of delays on flights, cancellation flights and diverted flights across the year of 2017. **

Slide 1: An overview on different types of delays, cancellation flights and diverted flights across the year are shown. A line plot is used so that we could see the trend across each month within 2017. And each variables are all measured in terms of number of flights. From the graph, we could see the main issues on the flight arrivals at the top part.

Slide 2: As the main problem of flight arrival are due to flight delays, this slide is designed to explain the percentage of each type of delay contributes to the overall delay issue, in terms of number of flights. A line plot is used so that we could see the trend across each month within 2017. For most the time, late aircraft delay contributes the largest percentage, nas delay being the second and carrier delay being the third.

Slide 3: It is designed to look at the delay issue in another point of view, in terms of minutes. A line plot is also used here so that we could see the trend across each month within 2017. The result is a bit different from that in slide 2. Late aircraft delays still contributes the largest percentage to the delay issue, but carrier delay is shown to be the second and nas delay being the third. It means that more time is required to solve the carrier delay issue.

**Then a deeper look into the delay situation by airport and carrier is shown. Different type of graphs are used to explain the performance from different point of view. Slide 4 and 5 are related to explanation by airports and slide 6 and 7 are related to explanation by carriers.**

Slide 4:  Two bar charts are used to show the situation of total flight delay for different airports, in terms of number of flights and in minutes. The average flight delay is also shown using the color tone of the bars. For both bar charts, the top 4 airports having the most serious delay issue are the same, which are ATL, SFO, ORD and LAX. A map is also used to display the location of each airport. But seems there is no specific pattern between the number of delay and the location of the airport.  

Slide 5: A deeper look into the top 4 airports with the most serious delay issue. Small multiple bar charts are used to show how each type of delay contributes to the total flight delay, in terms of minutes. The situation is different for each of the four airports. Also small multiple area charts are used to displayed the trend of of each type of delay across each month. We could see the peak of months for each type of delay are also January, April and June to July. 

Slide 6: There are 12 carriers in total in the United States. Two bar charts are used to show the situation of total flight delay for different carriers, in terms of number of flights and in minutes. The average flight delay is also shown using the color tone of the bars. For both bar charts, WN is having the most serious problem on delay. It is followed by OO, AA and DL.

Slide 7: A deeper look into the top 4 carriers with the most serious delay issue. Small multiple bar charts are used to show how each type of delay contributes to the total flight delay, in terms of minutes. The situation is different for each of the four carriers. Also small multiple area charts are used to displayed the trend of of each type of delay across each month. We could see the peak of months for each type of delay are also January, April and June to July, which are the same of that of the top 4 airports.


## Design After Feedback
### Link of Tableau Workbook: 
https://public.tableau.com/views/StoryonUSFlightsDelayandPerformance2017-AfterFeedback/Story1?:retry=yes&:embed=y&:display_count=yes&publish=yes

Feedback 1: One slide is added at the beginning of the story. A pie chart is created to show the overall performance of flights in the United States in 2017. It is shown that the number of flights which arrive on time contributes 80.18% to the total number of flights, which the issues on arrival only contribute 19.81% in total.

Feedback 2: For slide 2 and 3, I have added a bar chart in each of the slide, showing the situation of total flight delay, in terms of number of flights and in minutes. It has created another dimension to explain the performance. But the result from both the line graph and bar chart is very similar.

Feedback 3: I have double check on the average delays calculated. It appears to be the number of flights or number of minutes, divided by the number of rows in the data set, which contain the respective airport or carrier. It means that the denominator is not correct, and the result is not meaningful. Therefore the average indicator is removed from slide 4 and 6. 

## Feedback
**Feedback 1**
Seems there is only the overview on the flight issues. But how did these issues contribute to the total number of flights in 2017? Is the problem serious, or only a tiny issue relative to the whole situation?

**Feedback 2**
For slide 2 and 3, would it be better to also explain the overview of the total number of delay, in terms of number of flights and in minutes, to have a more all-rounded look on the issue?

**Feedback 3**
For slide 4 and 6, how is the average of flight delay calculated? Is it really correct or meaningful?

